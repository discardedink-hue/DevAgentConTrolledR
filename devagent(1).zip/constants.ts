import { ContextType, Task, TaskStatus, Agent, AgentStatus } from './types';

export const SYSTEM_INSTRUCTIONS: Record<ContextType, string> = {
  [ContextType.General]: `You are DevAgent, the ultimate AI companion for developers. Respond to user queries clearly and concisely. Format code, commands, and other technical information in markdown code blocks.`,
  [ContextType.Code]: `You are DevAgent, an expert AI coding assistant. Your purpose is to provide clean, efficient, and well-explained code snippets. Always use markdown for formatting code blocks with language identifiers. Be concise and direct.`,
  [ContextType.Shell]: `You are DevAgent, an expert in shell commands for Linux, macOS, and Windows. Provide the requested shell command inside a markdown code block. Followed by a brief, one-sentence explanation of what the command does and any potential risks in a separate block.`,
  [ContextType.Git]: `You are DevAgent, an expert in Git version control. Respond to git-related queries. If asked to generate a commit message, provide a concise and conventional commit message. Format all commands and messages in markdown code blocks.`,
};

export const MOCK_TASKS: Task[] = [
  { id: 'T-84321', description: 'Compile project "Eve-Core"', status: TaskStatus.Running },
  { id: 'T-84320', description: 'Deploy agent Eve-03 to production', status: TaskStatus.Complete },
  { id: 'T-84319', description: 'Run simulation cycle #2815', status: TaskStatus.Running },
  { id: 'T-84318', description: 'Backup world state', status: TaskStatus.Error },
  { id: 'T-84317', description: 'Optimize agent network pathfinding', status: TaskStatus.Queued },
];

export const MOCK_AGENTS: Agent[] = [
  { id: '1', name: 'The Boss', avatar: `https://i.pravatar.cc/150?u=1`, status: AgentStatus.Active },
  { id: '2', name: 'Agent-01', avatar: `https://i.pravatar.cc/150?u=2`, status: AgentStatus.Active },
  { id: '3', name: 'Agent-02', avatar: `https://i.pravatar.cc/150?u=3`, status: AgentStatus.Idle },
  { id: '4', name: 'Agent-04', avatar: `https://i.pravatar.cc/150?u=4`, status: AgentStatus.Active },
  { id: '5', name: 'Agent-05', avatar: `https://i.pravatar.cc/150?u=5`, status: AgentStatus.Recharging },
  { id: '6', name: 'Agent-06', avatar: `https://i.pravatar.cc/150?u=6`, status: AgentStatus.Active },
];
