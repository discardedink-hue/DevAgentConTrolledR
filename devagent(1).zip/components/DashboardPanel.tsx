import React from 'react';

interface DashboardPanelProps {
  title: string;
  children: React.ReactNode;
  className?: string;
}

export const DashboardPanel: React.FC<DashboardPanelProps> = ({ title, children, className = '' }) => {
  return (
    <div className={`bg-gray-800/60 rounded-xl border border-gray-700/50 shadow-2xl shadow-black/20 h-full flex flex-col ${className}`}>
      <div className="p-4 border-b border-gray-700/50 flex-shrink-0">
        <h2 className="font-bold text-lg text-gray-200">{title}</h2>
      </div>
      <div className="p-4 flex-1 overflow-y-auto">
        {children}
      </div>
    </div>
  );
};
