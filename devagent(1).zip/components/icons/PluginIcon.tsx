
import React from 'react';

export const PluginIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M12 2l-2.5 5L5 9l4.1 3.5L8 18l4-2.2L16 18l-1.1-5.5L19 9l-4.5-2L12 2z"></path>
    <path d="M5 21v-3"></path>
    <path d="M19 21v-3"></path>
    <path d="M12 15.8V21"></path>
  </svg>
);
