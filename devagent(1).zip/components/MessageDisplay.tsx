
import React from 'react';
import { Message, MessageAuthor } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';

interface CodeBlockProps {
  language: string;
  code: string;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ language, code }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-gray-900/70 rounded-lg my-2 border border-gray-700">
      <div className="flex justify-between items-center px-4 py-2 bg-gray-800/50 rounded-t-md">
        <span className="text-xs font-sans text-gray-400">{language || 'code'}</span>
        <button onClick={handleCopy} className="text-xs text-gray-400 hover:text-white transition">
          {copied ? 'Copied!' : 'Copy code'}
        </button>
      </div>
      <pre className="p-4 overflow-x-auto">
        <code className={`language-${language} font-mono text-sm`}>{code}</code>
      </pre>
    </div>
  );
};


const parseMessageText = (text: string) => {
  const parts = text.split(/(```[\w-]*\n[\s\S]*?\n```)/g);
  return parts.map((part, index) => {
    const match = part.match(/```([\w-]*)\n([\s\S]*?)\n```/);
    if (match) {
      const language = match[1] || '';
      const code = match[2];
      return <CodeBlock key={index} language={language} code={code} />;
    }
    return <p key={index} className="whitespace-pre-wrap">{part}</p>;
  });
};

export const MessageDisplay: React.FC<{ message: Message }> = ({ message }) => {
  const { author, text } = message;

  if (author === MessageAuthor.User) {
    return (
      <div className="flex justify-end">
        <div className="bg-primary max-w-2xl text-white p-4 rounded-lg rounded-br-none">
          <p className="font-mono text-sm">{text}</p>
        </div>
      </div>
    );
  }

  if (author === MessageAuthor.System) {
    return (
      <div className="text-center text-sm text-red-400 bg-red-900/50 p-3 rounded-lg">{text}</div>
    );
  }

  if (author === MessageAuthor.AI) {
    return (
      <div className="flex items-start space-x-4 max-w-full animate-fade-in">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-secondary flex items-center justify-center">
          <SparklesIcon className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 bg-gray-700/50 p-4 rounded-lg rounded-bl-none overflow-x-hidden">
          {text === '...' ? (
            <div className="flex items-center space-x-2">
              <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
	            <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
	            <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce"></span>
            </div>
          ) : (
            <div className="text-gray-200 text-sm leading-relaxed">{parseMessageText(text)}</div>
          )}
        </div>
      </div>
    );
  }

  return null;
};