import React from 'react';
import { DashboardPanel } from './DashboardPanel';
import { MOCK_AGENTS } from '../constants';
import { Agent, AgentStatus } from '../types';

const agentStatusColors: Record<AgentStatus, string> = {
    [AgentStatus.Active]: 'bg-green-500',
    [AgentStatus.Idle]: 'bg-yellow-500',
    [AgentStatus.Recharging]: 'bg-blue-500',
};

export const SystemAgentsPanel: React.FC = () => {
  const [agents, setAgents] = React.useState<Agent[]>(MOCK_AGENTS);

  return (
    <DashboardPanel title="System Agents">
      <div className="text-sm text-gray-400 mb-4">
        Manage and monitor all agents in the simulation.
      </div>
      <div className="space-y-3">
        {agents.map((agent) => (
          <div key={agent.id} className="flex items-center justify-between bg-gray-900/50 p-3 rounded-lg">
            <div className="flex items-center gap-3">
              <img src={agent.avatar} alt={agent.name} className="w-10 h-10 rounded-full" />
              <div>
                <p className="font-semibold text-white">{agent.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${agentStatusColors[agent.status]}`}></div>
                <span className="text-xs font-medium text-gray-300">{agent.status}</span>
            </div>
          </div>
        ))}
      </div>
    </DashboardPanel>
  );
};
