import React, { useRef, useEffect } from 'react';
import { Message, MessageAuthor, ContextType } from '../types';
import { MessageDisplay } from './MessageDisplay';
import { SendIcon } from './icons/SendIcon';
import { SuggestionBox } from './SuggestionBox';
import { SparklesIcon } from './icons/SparklesIcon';
import { CodeIcon } from './icons/CodeIcon';
import { ShellIcon } from './icons/ShellIcon';
import { GitIcon } from './icons/GitIcon';

interface ChatPanelProps {
  messages: Message[];
  isLoading: boolean;
  input: string;
  setInput: (value: string) => void;
  handleSubmit: (e: React.FormEvent) => Promise<void>;
  context: ContextType;
  setContext: (context: ContextType) => void;
}

const contextTabs = [
  { type: ContextType.General, label: 'General', icon: <SparklesIcon className="w-5 h-5" /> },
  { type: ContextType.Code, label: 'Code', icon: <CodeIcon className="w-5 h-5" /> },
  { type: ContextType.Shell, label: 'Shell', icon: <ShellIcon className="w-5 h-5" /> },
  { type: ContextType.Git, label: 'Git', icon: <GitIcon className="w-5 h-5" /> },
];

const ContextSwitcher: React.FC<{
  currentContext: ContextType;
  setContext: (context: ContextType) => void;
}> = ({ currentContext, setContext }) => (
  <div className="flex items-center gap-2 px-4 border-b border-gray-700/50">
    {contextTabs.map((tab) => (
      <button
        key={tab.type}
        onClick={() => setContext(tab.type)}
        className={`flex items-center gap-2 px-3 py-3 text-sm font-medium transition-colors ${
          currentContext === tab.type
            ? 'text-white border-b-2 border-purple-500'
            : 'text-gray-400 hover:text-white'
        }`}
        aria-pressed={currentContext === tab.type}
      >
        {tab.icon}
        <span>{tab.label}</span>
      </button>
    ))}
  </div>
);

export const Terminal: React.FC<ChatPanelProps> = ({ messages, isLoading, input, setInput, handleSubmit, context, setContext }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="h-full flex flex-col bg-gray-800/60 rounded-xl border border-gray-700/50 shadow-2xl shadow-black/20">
      <ContextSwitcher currentContext={context} setContext={setContext} />
      <div className="flex-1 p-6 overflow-y-auto">
        <div className="flex flex-col space-y-6">
          {messages.map((msg) => (
            <MessageDisplay key={msg.id} message={msg} />
          ))}
          {isLoading && <MessageDisplay message={{ id: 'loading', author: MessageAuthor.AI, text: '...', context: context }} />}
          <div ref={messagesEndRef} />
        </div>
      </div>
      <div className="flex-shrink-0 p-4 border-t border-gray-700/50">
        <SuggestionBox context={context} setInput={setInput} />
        <form onSubmit={handleSubmit} className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your command or message..."
            className="w-full bg-gray-900 border border-gray-600 rounded-lg p-4 pr-16 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-gradient-to-br from-purple-500 to-secondary disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
          >
            <SendIcon className="w-5 h-5 text-white" />
          </button>
        </form>
      </div>
    </div>
  );
};