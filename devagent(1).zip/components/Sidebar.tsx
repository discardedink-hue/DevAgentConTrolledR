
import React from 'react';
import { ContextType } from '../types';
import { CodeIcon } from './icons/CodeIcon';
import { ShellIcon } from './icons/ShellIcon';
import { GitIcon } from './icons/GitIcon';
import { PluginIcon } from './icons/PluginIcon';
import { SettingsIcon } from './icons/SettingsIcon';

interface SidebarProps {
  currentContext: ContextType;
  setContext: (context: ContextType) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors duration-200 ${
      isActive ? 'bg-purple-600/30 text-white' : 'text-gray-400 hover:bg-gray-700/50 hover:text-white'
    }`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </button>
);

export const Sidebar: React.FC<SidebarProps> = ({ currentContext, setContext, isOpen, setIsOpen }) => {
  const navItems = [
    { type: ContextType.Code, label: 'Code', icon: <CodeIcon className="w-5 h-5" /> },
    { type: ContextType.Shell, label: 'Shell', icon: <ShellIcon className="w-5 h-5" /> },
    { type: ContextType.Git, label: 'Git', icon: <GitIcon className="w-5 h-5" /> },
  ];

  return (
    <>
      <aside className={`absolute md:relative z-20 md:z-auto bg-gray-900/70 backdrop-blur-lg border-r border-gray-700/50 flex-shrink-0 w-64 h-full flex flex-col p-4 transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}>
        <div className="flex-1">
          <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-4 px-2">Context</h2>
          <nav className="flex flex-col space-y-1">
            {navItems.map((item) => (
              <NavItem
                key={item.type}
                icon={item.icon}
                label={item.label}
                isActive={currentContext === item.type}
                onClick={() => {
                  setContext(item.type);
                  if (window.innerWidth < 768) setIsOpen(false);
                }}
              />
            ))}
          </nav>

          <div className="my-8 border-t border-gray-700/50"></div>

          <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-4 px-2">Tools</h2>
          <nav className="flex flex-col space-y-1">
             <NavItem icon={<PluginIcon className="w-5 h-5" />} label="Plugins" isActive={false} onClick={() => {}} />
             <NavItem icon={<SettingsIcon className="w-5 h-5" />} label="Settings" isActive={false} onClick={() => {}} />
          </nav>
        </div>
        <div className="text-center text-xs text-gray-500">
            <p>DevAgent v1.0</p>
            <p>Powered by Gemini</p>
        </div>
      </aside>
      {isOpen && <div onClick={() => setIsOpen(false)} className="fixed inset-0 bg-black/50 z-10 md:hidden"></div>}
    </>
  );
};
