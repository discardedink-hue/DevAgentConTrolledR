import React, { useState } from 'react';
import { Header } from './components/Header';
import { Terminal as ChatPanel } from './components/Terminal';
import { ConversationPanel } from './components/ConversationPanel';
import { SystemArchitecturePanel } from './components/SystemArchitecturePanel';
import { ActiveTasksPanel } from './components/ActiveTasksPanel';
import { SystemAgentsPanel } from './components/SystemAgentsPanel';
import { AgenticTerminalPanel } from './components/AgenticTerminalPanel';
import { ContextType, Message, MessageAuthor } from './types';
import { runQuery } from './services/geminiService';

const App: React.FC = () => {
  // State for the main Agentic Terminal
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-main',
      author: MessageAuthor.AI,
      text: 'Agentic Terminal initialized. Select a context and issue your command.',
      context: ContextType.General,
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [context, setContext] = useState<ContextType>(ContextType.General);
  
  // State for the top Conversation Panel
  const [convoMessages, setConvoMessages] = useState<Message[]>([
    {
      id: 'welcome-convo',
      author: MessageAuthor.AI,
      text: 'Welcome to the Control Center. Issue a command to all agents or ask a general question.',
      context: ContextType.General,
    }
  ]);
  const [convoInput, setConvoInput] = useState('');
  const [isConvoLoading, setIsConvoLoading] = useState(false);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      author: MessageAuthor.User,
      text: input,
      context: context,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const aiResponse = await runQuery(input, context);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        author: MessageAuthor.AI,
        text: aiResponse,
        context: context,
      };
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        author: MessageAuthor.System,
        text: 'Sorry, I encountered an error. Please check the console for details or try again.',
        context: context,
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleConvoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!convoInput.trim() || isConvoLoading) return;

    const userMessage: Message = {
      id: `convo-${Date.now()}`,
      author: MessageAuthor.User,
      text: convoInput,
      context: ContextType.General,
    };

    setConvoMessages((prev) => [...prev, userMessage]);
    setConvoInput('');
    setIsConvoLoading(true);

    try {
      // The conversation panel always uses the General context.
      const aiResponse = await runQuery(convoInput, ContextType.General);
      const aiMessage: Message = {
        id: `convo-${Date.now() + 1}`,
        author: MessageAuthor.AI,
        text: aiResponse,
        context: ContextType.General,
      };
      setConvoMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: Message = {
        id: `convo-${Date.now() + 1}`,
        author: MessageAuthor.System,
        text: 'Sorry, I encountered an error. Please check the console for details or try again.',
        context: ContextType.General,
      };
      setConvoMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsConvoLoading(false);
    }
  };


  return (
    <div className="flex flex-col h-screen w-full bg-gray-900 text-gray-100 font-sans overflow-hidden">
      <Header />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Column 1 - Main Interaction */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-1 h-full min-h-[300px]"><ConversationPanel 
              messages={convoMessages}
              isLoading={isConvoLoading}
              input={convoInput}
              setInput={setConvoInput}
              handleSubmit={handleConvoSubmit}
            /></div>
            <div className="md:col-span-1 h-full min-h-[300px]"><SystemArchitecturePanel /></div>
          </div>
          <div className="flex-1 min-h-[500px]">
            <ChatPanel
              messages={messages}
              isLoading={isLoading}
              input={input}
              setInput={setInput}
              handleSubmit={handleSubmit}
              context={context}
              setContext={setContext}
            />
          </div>
        </div>

        {/* Column 2 - Monitoring */}
        <div className="lg:col-span-1 flex flex-col gap-6">
          <ActiveTasksPanel />
          <SystemAgentsPanel />
          <AgenticTerminalPanel />
        </div>
      </main>
    </div>
  );
};

export default App;