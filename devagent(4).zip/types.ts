export enum ContextType {
  Code = 'Code',
  Shell = 'Shell',
  Git = 'Git',
  General = 'General',
}

export enum MessageAuthor {
  User = 'user',
  AI = 'ai',
  System = 'system',
}

export interface Message {
  id: string;
  author: MessageAuthor;
  text: string;
  context: ContextType;
}

export interface Plugin {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  enabled: boolean;
}

export enum TaskStatus {
  Running = 'Running',
  Complete = 'Complete',
  Error = 'Error',
  Queued = 'Queued',
}

export interface Task {
  id: string;
  description: string;
  status: TaskStatus;
}

export enum AgentStatus {
  Active = 'Active',
  Idle = 'Idle',
  Recharging = 'Recharging',
}

export interface Agent {
  id: string;
  name: string;
  avatar: string;
  status: AgentStatus;
}
