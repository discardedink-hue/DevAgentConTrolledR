import React from 'react';
import { Terminal } from './components/Terminal';

const App: React.FC = () => {
  return (
    <div className="flex flex-col h-screen w-full bg-gray-900 text-gray-100 font-sans overflow-hidden">
      <Terminal />
    </div>
  );
};

export default App;
