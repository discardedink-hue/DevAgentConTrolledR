import { GoogleGenAI } from "@google/genai";
import { ContextType } from '../types';
import { SYSTEM_INSTRUCTIONS } from '../constants';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const runQuery = async (prompt: string, context: ContextType): Promise<string> => {
  try {
    const systemInstruction = SYSTEM_INSTRUCTIONS[context];

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        return `Error interacting with AI: ${error.message}. Check the browser console for more details. Your API key might be invalid or missing.`;
    }
    return 'An unknown error occurred while interacting with the AI.';
  }
};