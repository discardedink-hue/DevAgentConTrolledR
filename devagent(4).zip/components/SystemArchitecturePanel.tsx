import React from 'react';
import { DashboardPanel } from './DashboardPanel';

export const SystemArchitecturePanel: React.FC = () => {
  return (
    <DashboardPanel title="System Architecture">
      <div className="h-full flex flex-col">
          <p className="text-sm text-gray-400 mb-4">High-level architecture of the DevAgent system.</p>
          <div className="flex-1 rounded-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1550439062-609e1531270e?q=80&w=800&auto=format&fit=crop" 
                alt="System Architecture" 
                className="w-full h-full object-cover"
              />
          </div>
      </div>
    </DashboardPanel>
  );
};
