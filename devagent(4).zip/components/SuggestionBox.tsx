import React from 'react';
import { ContextType } from '../types';

interface SuggestionBoxProps {
  context: ContextType;
  setInput: (value: string) => void;
}

const suggestions: Record<ContextType, string[]> = {
  [ContextType.General]: [
    'What is the difference between let, const, and var?',
    'Explain the box model in CSS.',
    'How to make an API call in React?',
  ],
  [ContextType.Code]: [
    'Create a React component for a login form.',
    'Explain how promises work in JavaScript.',
    'Write a Python script to parse a CSV file.'
  ],
  [ContextType.Shell]: [
    'List all files in the current directory.',
    'Find all files named `config.json` in subdirectories.',
    'Show current memory usage.'
  ],
  [ContextType.Git]: [
    'Generate a commit message for my recent changes.',
    'How do I revert the last commit?',
    'Explain the difference between `git merge` and `git rebase`.'
  ]
};

export const SuggestionBox: React.FC<SuggestionBoxProps> = ({ context, setInput }) => {
  const currentSuggestions = suggestions[context] || suggestions[ContextType.General];

  return (
    <div className="mb-2 flex items-center flex-wrap gap-2">
      {currentSuggestions.map((suggestion, index) => (
        <button
          key={index}
          onClick={() => setInput(suggestion)}
          className="px-3 py-1 bg-gray-700/80 text-gray-300 text-xs rounded-full hover:bg-gray-600 transition-colors"
        >
          {suggestion}
        </button>
      ))}
    </div>
  );
};