import React from 'react';
import { Modal } from './Modal';
import { Plugin } from '../types';
import { ToggleSwitch } from './ToggleSwitch';

interface PluginModalProps {
  isOpen: boolean;
  onClose: () => void;
  plugins: Plugin[];
  onTogglePlugin: (pluginId: string) => void;
}

export const PluginModal: React.FC<PluginModalProps> = ({ isOpen, onClose, plugins, onTogglePlugin }) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Manage Plugins">
        <p className="text-sm text-gray-400 mb-6">
            Enable or disable plugins to customize DevAgent's capabilities.
        </p>
        <div className="space-y-4">
            {plugins.map((plugin) => (
                <div key={plugin.id} className="flex items-center justify-between p-4 bg-gray-900/50 rounded-lg border border-gray-700">
                    <div className="flex items-center gap-4">
                        <div className="flex-shrink-0">
                            {plugin.icon}
                        </div>
                        <div>
                            <h3 className="font-semibold text-white">{plugin.name}</h3>
                            <p className="text-sm text-gray-400">{plugin.description}</p>
                        </div>
                    </div>
                    <ToggleSwitch 
                        enabled={plugin.enabled} 
                        onChange={() => onTogglePlugin(plugin.id)} 
                    />
                </div>
            ))}
        </div>
    </Modal>
  );
};
