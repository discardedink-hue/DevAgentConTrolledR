import React from 'react';
import { DashboardPanel } from './DashboardPanel';
import { MOCK_TASKS } from '../constants';
import { Task, TaskStatus } from '../types';

const statusColors: Record<TaskStatus, string> = {
  [TaskStatus.Running]: 'text-blue-400 bg-blue-900/50',
  [TaskStatus.Complete]: 'text-green-400 bg-green-900/50',
  [TaskStatus.Error]: 'text-red-400 bg-red-900/50',
  [TaskStatus.Queued]: 'text-yellow-400 bg-yellow-900/50',
};

export const ActiveTasksPanel: React.FC = () => {
  const [tasks, setTasks] = React.useState<Task[]>(MOCK_TASKS);

  return (
    <DashboardPanel title="Active and Recent Tasks">
      <div className="text-sm text-gray-400 mb-4">
        Monitor the status of tasks being handled by the system.
      </div>
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-gray-700 text-gray-400">
            <th className="py-2 font-semibold">Task ID</th>
            <th className="py-2 font-semibold">Description</th>
            <th className="py-2 font-semibold text-right">Status</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task) => (
            <tr key={task.id} className="border-b border-gray-700/50">
              <td className="py-3 font-mono text-gray-500">{task.id}</td>
              <td className="py-3 text-gray-300">{task.description}</td>
              <td className="py-3 text-right">
                <span className={`px-2 py-1 rounded-md text-xs font-bold ${statusColors[task.status]}`}>
                  {task.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </DashboardPanel>
  );
};
