import React, { useRef, useEffect } from 'react';
import { DashboardPanel } from './DashboardPanel';
import { ContextType, Message, MessageAuthor } from '../types';
import { MessageDisplay } from './MessageDisplay';
import { SpinnerIcon } from './icons/SpinnerIcon';

interface ConversationPanelProps {
  messages: Message[];
  isLoading: boolean;
  input: string;
  setInput: (value: string) => void;
  handleSubmit: (e: React.FormEvent) => Promise<void>;
}

export const ConversationPanel: React.FC<ConversationPanelProps> = ({
  messages,
  isLoading,
  input,
  setInput,
  handleSubmit,
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <DashboardPanel title="Conversation">
      <div className="flex flex-col h-full">
        <p className="text-sm text-gray-400 mb-4 flex-shrink-0">
          Interact with DevAgent using natural language.
        </p>

        <div className="flex-1 mb-4 overflow-y-auto pr-2 space-y-4">
          {messages.map((msg) => (
            <MessageDisplay key={msg.id} message={msg} />
          ))}
          {isLoading && (
            <MessageDisplay
              message={{
                id: 'loading-convo',
                author: MessageAuthor.AI,
                text: '...',
                context: ContextType.General,
              }}
            />
          )}
          <div ref={messagesEndRef} />
        </div>
        
        <form onSubmit={handleSubmit} className="flex gap-2 flex-shrink-0">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Issue a command to all agents..."
            className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono text-sm"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="px-4 py-2 rounded-lg bg-blue-600 text-white font-semibold text-sm hover:bg-blue-700 transition-colors whitespace-nowrap disabled:bg-gray-600 disabled:cursor-not-allowed flex items-center justify-center w-[150px]"
          >
            {isLoading ? (
              <>
                <SpinnerIcon className="w-5 h-5 mr-2" />
                <span>Issuing...</span>
              </>
            ) : (
              'Issue Command'
            )}
          </button>
        </form>
      </div>
    </DashboardPanel>
  );
};