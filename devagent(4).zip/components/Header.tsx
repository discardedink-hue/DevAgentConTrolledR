import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';
import { DownloadIcon } from './icons/DownloadIcon';

interface HeaderProps {}

export const Header: React.FC<HeaderProps> = () => {
  return (
    <header className="flex-shrink-0 bg-gray-900/80 backdrop-blur-sm border-b border-gray-700/50 flex items-center justify-between px-4 md:px-6 h-16 z-10">
      <div className="flex items-center gap-2">
        <SparklesIcon className="w-7 h-7 text-purple-400" />
        <h1 className="text-2xl font-display font-bold bg-gradient-to-r from-purple-400 to-secondary text-transparent bg-clip-text">
          DevAgent Control Center
        </h1>
      </div>
      <button className="flex items-center gap-2 px-4 py-2 bg-gray-700/50 border border-gray-600 rounded-lg text-sm font-medium text-gray-200 hover:bg-gray-700 transition-colors">
        <DownloadIcon className="w-4 h-4" />
        <span>Download</span>
      </button>
    </header>
  );
};
