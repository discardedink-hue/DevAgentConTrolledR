
import React, { useRef, useEffect, useState } from 'react';
import { Message, MessageAuthor, ContextType, Plugin } from '../types';
import { MessageDisplay } from './MessageDisplay';
import { SendIcon } from './icons/SendIcon';
import { SuggestionBox } from './SuggestionBox';
import { SparklesIcon } from './icons/SparklesIcon';
import { CodeIcon } from './icons/CodeIcon';
import { ShellIcon } from './icons/ShellIcon';
import { GitIcon } from './icons/GitIcon';
import { PluginIcon } from './icons/PluginIcon';
import { runQuery } from '../services/geminiService';
import { MOCK_PLUGINS } from '../constants';
import { PluginModal } from './PluginModal';

const contextTabs = [
  { type: ContextType.General, label: 'General', icon: <SparklesIcon className="w-5 h-5" /> },
  { type: ContextType.Code, label: 'Code', icon: <CodeIcon className="w-5 h-5" /> },
  { type: ContextType.Shell, label: 'Shell', icon: <ShellIcon className="w-5 h-5" /> },
  { type: ContextType.Git, label: 'Git', icon: <GitIcon className="w-5 h-5" /> },
];

const Header: React.FC<{
  currentContext: ContextType;
  setContext: (context: ContextType) => void;
  onPluginsClick: () => void;
}> = ({ currentContext, setContext, onPluginsClick }) => (
  <header className="flex-shrink-0 bg-gray-900/80 backdrop-blur-sm border-b border-gray-700/50 flex items-center justify-between px-4 h-16 z-10">
    <div className="flex items-center gap-2">
      <SparklesIcon className="w-7 h-7 text-purple-400 hidden sm:block" />
      <h1 className="text-xl sm:text-2xl font-display font-bold bg-gradient-to-r from-purple-400 to-secondary text-transparent bg-clip-text">
        DevAgent
      </h1>
    </div>
    <div className="flex items-center gap-2 px-4 border-x border-gray-700/50">
      {contextTabs.map((tab) => (
        <button
          key={tab.type}
          onClick={() => setContext(tab.type)}
          className={`flex items-center gap-2 px-2 sm:px-3 py-2 text-sm font-medium transition-colors rounded-md ${
            currentContext === tab.type
              ? 'text-white bg-gray-700/50'
              : 'text-gray-400 hover:text-white hover:bg-gray-800/60'
          }`}
          aria-pressed={currentContext === tab.type}
          title={tab.label}
        >
          {tab.icon}
          <span className="hidden sm:inline">{tab.label}</span>
        </button>
      ))}
    </div>
    <button onClick={onPluginsClick} className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-400 hover:text-white hover:bg-gray-800/60 rounded-md transition-colors" >
      <PluginIcon className="w-5 h-5" />
      <span className="hidden sm:inline">Plugins</span>
    </button>
  </header>
);

export const Terminal: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-main',
      author: MessageAuthor.AI,
      text: 'Welcome to DevAgent. I am your unified AI assistant. Select a context and let\'s begin.',
      context: ContextType.General,
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [context, setContext] = useState<ContextType>(ContextType.General);
  const [isPluginModalOpen, setIsPluginModalOpen] = useState(false);
  const [plugins, setPlugins] = useState<Plugin[]>(MOCK_PLUGINS);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const handleTogglePlugin = (pluginId: string) => {
    setPlugins(prevPlugins =>
      prevPlugins.map(plugin =>
        plugin.id === pluginId ? { ...plugin, enabled: !plugin.enabled } : plugin
      )
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      author: MessageAuthor.User,
      text: input,
      context,
    };

    setMessages((prev) => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setIsLoading(true);

    try {
      const aiResponse = await runQuery(currentInput, context);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        author: MessageAuthor.AI,
        text: aiResponse,
        context,
      };
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        author: MessageAuthor.System,
        text: 'Sorry, I encountered an error. Please check the console for details or try again.',
        context,
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleExplainCommand = async (command: string) => {
     // FIX: Correctly construct the prompt for explaining a shell command.
     const prompt = `Explain this shell command in simple terms, focusing on what each part does: \`${command}\``;
     setIsLoading(true);
     try {
       const aiResponse = await runQuery(prompt, ContextType.Shell);
       const aiMessage: Message = {
         id: (Date.now() + 1).toString(),
         author: MessageAuthor.AI,
         text: `**Explanation for \`${command}\`:**\n\n${aiResponse}`,
         context: ContextType.Shell,
       };
       setMessages((prev) => [...prev, aiMessage]);
     } catch (error) {
       console.error(error);
       const errorMessage: Message = {
         id: (Date.now() + 1).toString(),
         author: MessageAuthor.System,
         text: 'Sorry, I couldn\'t explain that command.',
         context: ContextType.Shell,
       };
       setMessages((prev) => [...prev, errorMessage]);
     } finally {
       setIsLoading(false);
     }
  }

  return (
    <>
      <div className="h-full flex flex-col bg-gray-800/60 rounded-xl border border-gray-700/50 shadow-2xl shadow-black/20 m-0 sm:m-4">
        <Header currentContext={context} setContext={setContext} onPluginsClick={() => setIsPluginModalOpen(true)} />
        <div className="flex-1 p-6 overflow-y-auto">
          <div className="flex flex-col space-y-6">
            {messages.map((msg) => (
              // FIX: Pass onExplainCommand prop to MessageDisplay. This was causing a type error.
              <MessageDisplay key={msg.id} message={msg} onExplainCommand={handleExplainCommand} />
            ))}
            {/* FIX: Pass onExplainCommand prop to MessageDisplay. This was causing a type error. */}
            {isLoading && <MessageDisplay message={{ id: 'loading', author: MessageAuthor.AI, text: '...', context: context }} onExplainCommand={() => {}} />}
            <div ref={messagesEndRef} />
          </div>
        </div>
        <div className="flex-shrink-0 p-4 border-t border-gray-700/50">
          <SuggestionBox context={context} setInput={setInput} />
          <form onSubmit={handleSubmit} className="relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your command or message..."
              className="w-full bg-gray-900 border border-gray-600 rounded-lg p-4 pr-16 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-gradient-to-br from-purple-500 to-secondary disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
            >
              <SendIcon className="w-5 h-5 text-white" />
            </button>
          </form>
        </div>
      </div>
      <PluginModal 
        isOpen={isPluginModalOpen} 
        onClose={() => setIsPluginModalOpen(false)} 
        plugins={plugins}
        onTogglePlugin={handleTogglePlugin}
      />
    </>
  );
};
